#include <ros/ros.h>
#include <sensor_msgs/JointState.h>
#include <std_msgs/Float64.h>



std_msgs::Float64 msg_jopint1;
std_msgs::Float64 msg_jopint2;
std_msgs::Float64 msg_jopint3;
std_msgs::Float64 msg_jopint4;
std_msgs::Float64 msg_jopint5;
std_msgs::Float64 msg_jopint6;
std_msgs::Float64 msg_jopint7;
std_msgs::Float64 msg_jopint8;
std_msgs::Float64 msg_jopint9;


ros::Subscriber gui_sub;
ros::Publisher pub_joint1;
ros::Publisher pub_joint2;
ros::Publisher pub_joint3;
ros::Publisher pub_joint4;
ros::Publisher pub_joint5;
ros::Publisher pub_joint6;
ros::Publisher pub_joint7;
ros::Publisher pub_joint8;
ros::Publisher pub_joint9;


void gui_callback(const sensor_msgs::JointState msg)
{
    msg_jopint1.data = msg.position[1];
    msg_jopint2.data = msg.position[2];
    msg_jopint3.data =msg.position[3];
    msg_jopint4.data = msg.position[4];
    msg_jopint5.data = msg.position[5];
    msg_jopint6.data =msg.position[6];
    msg_jopint7.data =msg.position[7];
    msg_jopint8.data =msg.position[8];
    msg_jopint9.data =msg.position[9];

   pub_joint1.publish(msg_jopint1);
   pub_joint2.publish(msg_jopint2);
   pub_joint3.publish(msg_jopint3);
   pub_joint4.publish(msg_jopint4);
   pub_joint5.publish(msg_jopint5);
   pub_joint6.publish(msg_jopint6);
   pub_joint7.publish(msg_jopint7);
   pub_joint8.publish(msg_jopint8);
   pub_joint9.publish(msg_jopint9);
}



int main(int argc, char **argv)
{

	//Initializing ROS node with a name of demo_topic_publisher
	ros::init(argc, argv,"send_goal_gui");

	//Created a node handle object
	ros::NodeHandle n;


       gui_sub = n.subscribe("/joint_states",100,gui_callback);

        pub_joint1 = n.advertise<std_msgs::Float64>("/seven_dof_arm/joint1_position_controller/command",100); 
        pub_joint2 = n.advertise<std_msgs::Float64>("/seven_dof_arm/joint2_position_controller/command",100); 
        pub_joint3 = n.advertise<std_msgs::Float64>("/seven_dof_arm/joint3_position_controller/command",100); 
        pub_joint4 = n.advertise<std_msgs::Float64>("/seven_dof_arm/joint4_position_controller/command",100); 
        pub_joint5 = n.advertise<std_msgs::Float64>("/seven_dof_arm/joint5_position_controller/command",100); 
        pub_joint6 = n.advertise<std_msgs::Float64>("/seven_dof_arm/joint6_position_controller/command",100); 
        pub_joint7 = n.advertise<std_msgs::Float64>("/seven_dof_arm/joint7_position_controller/command",100); 
        pub_joint8 = n.advertise<std_msgs::Float64>("/seven_dof_arm/joint8_position_controller/command",100); 
        pub_joint9 = n.advertise<std_msgs::Float64>("/seven_dof_arm/joint9_position_controller/command",100); 



	ros::spin();





	return 0;
}
