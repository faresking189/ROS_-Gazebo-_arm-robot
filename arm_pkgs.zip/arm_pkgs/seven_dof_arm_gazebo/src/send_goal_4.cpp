#include <ros/ros.h>
#include <std_msgs/Float64.h>



std_msgs::Float64 msg_jopint1;
std_msgs::Float64 msg_jopint2;
std_msgs::Float64 msg_jopint4;
std_msgs::Float64 msg_jopint6;

ros::Publisher pub_joint1;
ros::Publisher pub_joint2;
ros::Publisher pub_joint4;
ros::Publisher pub_joint6;

float angle_1= 0/10;
float angle_2= 0/10;
float angle_4= 0/10;
float angle_6= 0/10;

int main(int argc, char **argv)
{

	//Initializing ROS node with a name of demo_topic_publisher
	ros::init(argc, argv,"send_goal_4");

	//Created a node handle object
	ros::NodeHandle n;

ros::Rate rate(10);
        pub_joint1 = n.advertise<std_msgs::Float64>("/seven_dof_arm/joint1_position_controller/command",100); 
        pub_joint2 = n.advertise<std_msgs::Float64>("/seven_dof_arm/joint2_position_controller/command",100); 
        pub_joint4 = n.advertise<std_msgs::Float64>("/seven_dof_arm/joint4_position_controller/command",100); 
        pub_joint6 = n.advertise<std_msgs::Float64>("/seven_dof_arm/joint6_position_controller/command",100); 

  for(int i=1; i<= 10; i++ ) {
    msg_jopint1.data -= angle_1;
    msg_jopint2.data -= angle_2;
    msg_jopint4.data -= angle_4;
    msg_jopint6.data -= angle_6;

   pub_joint1.publish(msg_jopint1);
   pub_joint2.publish(msg_jopint2);
   pub_joint4.publish(msg_jopint4);
   pub_joint6.publish(msg_jopint6);

	rate.sleep();


}



	ros::spinOnce();
       

 


   // msg_jopint1.data = 0.5;

 
  // pub_joint1.publish(msg_jopint1);



	return 0;

}
