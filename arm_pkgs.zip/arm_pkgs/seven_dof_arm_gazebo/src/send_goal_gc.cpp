#include <ros/ros.h>
#include <std_msgs/Float64.h>



std_msgs::Float64 msg_jopint1;


ros::Publisher pub_joint1;


float angle_1= -0.04/10;


int main(int argc, char **argv)
{

	//Initializing ROS node with a name of demo_topic_publisher
	ros::init(argc, argv,"send_goal_gc");

	//Created a node handle object
	ros::NodeHandle n;

ros::Rate rate(10);
        pub_joint1 = n.advertise<std_msgs::Float64>("/seven_dof_arm/joint9_position_controller/command",100); 
        


  for(int i=1; i<= 10; i++ ) {
    msg_jopint1.data += angle_1;
   

   pub_joint1.publish(msg_jopint1);


	rate.sleep();


}

	ros::spinOnce();
       

 


   // msg_jopint1.data = 0.5;

 
  // pub_joint1.publish(msg_jopint1);



	return 0;

}
